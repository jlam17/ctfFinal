
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;

import javax.swing.JPanel;

//import main.Algorithm;
import processing.core.*;



/**
 * the surface where drawings are made
 * @author hdesouza538
 *
 */
public class DrawingSurface extends PApplet {
	/**
	 * chooses which algorithm to draw
	 * @author Wikipedia
	 *
	 */
	enum Algorithm {
		RANDOM_DFS_RECURSIVE,
		RANDOM_DFS_NONRECURSIVE,
		RANDOM_BFS,
		PRIM,
		RECURSIVE_DIVISION,
		ALDOUS_BRODER,
		WILSON,
		SIDEWINDER,
		BINARY_TREE
	}
	
	/**
	 * generates a grid with the parameters
	 * @param numCols number of columns
	 * @param numRows number of rows
	 * @param startCol start column
	 * @param startRow start row
	 * @param algorithm algorithm type
	 * @return a grid that fits the parameters
	 */
	public static Grid maze(int numCols, int numRows, int startCol, int startRow, Algorithm algorithm) {
		Grid grid = new Grid(numCols, numRows);
		int startVertex = grid.vertex(startCol, startRow);
		BitSet visited = new BitSet(numCols * numRows);
		randomDFSRecursive(grid, startVertex, visited);
		return grid;
	}
	
	/**
	 * generates the maze
	 * @param grid the grid passed in
	 * @param v integer that helps with direction
	 * @param visited a bit set
	 */
	static void randomDFSRecursive(Grid grid, int v, BitSet visited) {
		visited.set(v);
		for (Direction dir = unvisitedDir(grid, v, visited); dir != null; dir = unvisitedDir(grid, v,
				visited)) {
			grid.addEdge(v, dir);
			randomDFSRecursive(grid, grid.neighbor(v, dir), visited);
		}
	}
	
	/**
	 * helps generates the maze
	 * @param grid the grid passed in
	 * @param v integer that helps with direction
	 * @param visited a bit set
	 * @return a direction
	 */
	static Direction unvisitedDir(Grid grid, int v, BitSet visited) {
		List<Direction> unvisitedDirections = unvisitedDirections(grid, v, visited);
		return unvisitedDirections.isEmpty() ? null : unvisitedDirections.get(0);
	}
	
	/**
	 * helps generates the maze
	 * @param grid the grid passed in
	 * @param v integer that helps with direction
	 * @param visited a bit set
	 * @return a list of directions
	 */
	static List<Direction> unvisitedDirections(Grid grid, int v, BitSet visited) {
		List<Direction> candidates = new ArrayList<>(4);
		for (Direction dir : Direction.values()) {
			int neighbor = grid.neighbor(v, dir);
			if (neighbor != Grid.NO_VERTEX && !visited.get(neighbor)) {
				candidates.add(dir);
			}
		}
		Collections.shuffle(candidates);
		return candidates;
	}
	
	Player player1, player2;
	int numFrames; // The number of frames in the animation
	int currentFrame = 0;
	PImage[] images;
	PImage wall, flag1, flag2;
	Flag f1, f2;
	boolean[] keyDown;
	String maze;

	/**
	 * constructs the DrawingSurface, initializes player variables
	 */
	public DrawingSurface() {
		super();
		numFrames = 13;
		player1 = new Player(1, 10, 50);
		player2 = new Player(2, 100, 50);
		f1 = new Flag(flag1, player1, player2, 300, 300);
		f2 = new Flag(flag2, player2, player1, 100, 300);
		images = new PImage[numFrames];
		keyDown = new boolean[4];
	}

	/**
	 * the settings of the DrawingSurface
	 */
	public void settings() {
		size(1000, 960);
	}

	/**
	 * initial one-time run commands
	 */
	public void setup() {
		
		settings();
		frameRate(24);
		
		flag1 = loadImage("flag.png");
		flag2 = loadImage("flag.png");
		
		images[9] = loadImage("background.png");
		images[9].resize(1000, 1000);
		this.image(images[9], 0, 0);
		
		//change the first two values in the maze call to change width/height
		maze = maze(11, 9, 0, 0, Algorithm.values()[0]).toString();
		
		//this.text("", 100, 100);
		wall = loadImage("wall.png");

		
		
		
		
		//Loading and resizing the images
		images[0] = loadImage("knightStand.png");
		images[0].resize(126/4, 126/4);
		images[1] = loadImage("knightWalkRight.png");
		images[1].resize(96/4, 126/4);
		images[2] = loadImage("knightAttack1.png");
		images[2].resize(128/4,126/4);
		images[3] = loadImage("knightAttack2.png");
		images[3].resize(192/4,126/4);
		images[4] = loadImage("knightWalkDown1.png");
		images[4].resize(96/4, 128/4);
		images[5] = loadImage("knightWalkDown2.png");
		images[5].resize(128/4,128/4);
		images[6] = loadImage("knightStandUp.png");
		images[6].resize(126/4, 127/4);
		images[7] = loadImage("knightWalkUp1.png");
		images[7].resize(96/4, 126/4);
		images[8] = loadImage("knightWalkUp2.png");
		images[8].resize(128/4, 126/4);
		images[9] = loadImage("background.png");
		images[9].resize(1000, 1000);
		images[10] = loadImage("knightStandLeft.png");
		images[10].resize(126/4, 126/4);
		images[11] = loadImage("knightWalkLeft.png");
		images[11].resize(96/4, 126/4);
		images[12] = loadImage("knightStandDown.png");
		images[12].resize(126/4, 128/4);
		
	}

	/**
	 * draws the background and players
	 */
	public void draw() {
		background(255);
		
		this.image(images[9], 0, 0);
		player1.draw(this, images, currentFrame);
		f1.draw(this, flag1, (float)f1.getX(), (float)f1.getY());
		f2.draw(this, flag2, (float)f2.getX(), (float)f2.getY());
		drawMaze();
		

//		
//		int y = 5;
//		int x = 20;
//		for(int i=0; i<874; i++) {
//			x=20;
//			y+=36;
//			while(!maze.substring(i, i+1).equals("\n")) {
//				if(!maze.substring(i, i+1).equals(" ")) {
//					if(maze.substring(i, i+1).equals("-")) {
//						//this.line(x, y, x+18, y);
//						this.image(wall, x, y, width/4, height/8);
//					}
//					else {
//						//this.line(x, y, x, y+18);
//						this.image(wall, x, y, width/8, height/4);
//						
//					}
//				}
//				i++;
//				x+=18;
//			}
//		}
	}

	/**
	 * checks for what to do if a mouse button is pressed
	 */
	public void mousePressed() {

	}

	/**
	 * checks for what to do if a certain key is pressed
	 */
	public void keyPressed() {
		if (key == 119 || key == 87) { // w
			player1.moveUp();
			keyDown[0] = true;
			if (currentFrame == 7) {
				currentFrame = 8;
			} else {
				currentFrame = 7;
			}
		} 
		else if (key == 115 || key == 83) { // s
			player1.moveDown();
			keyDown[2] = true;
			if (currentFrame == 4) {
				currentFrame = 5;
			} else {
				currentFrame = 4;
			}
		}
		else if (key == 97 || key == 65) { // a
			player1.moveLeft();
			keyDown[1] = true;
			if (currentFrame == 11) {
				currentFrame = 10;
			} else {
				currentFrame = 11;
			}
		} 
		else if (key == 100 || key == 68) { // d
			player1.moveRight();
			keyDown[3] = true;
			if (currentFrame == 1) {
				currentFrame = 0;
			} else {
				currentFrame = 1;
			}
		}
		
		
//		if (keyCode == UP) {
//			player2.moveUp();
//		}
//		if (keyCode == DOWN) {
//			player2.moveDown();
//		}
//		if (keyCode == RIGHT) {
//			player2.moveRight();
//		}
//		if (keyCode == LEFT) {
//			player2.moveLeft();
//		}
	}
	
	/**
	 * checks what happens if a key is released
	 */
	public void keyReleased() {
		if (key == 119) { // w
			keyDown[0] = false;
		}
		if (key == 97) { // a
			keyDown[1] = false;
		}
		if (key == 115) { // s
			keyDown[2] = false; 
		}
		if (key == 100) { // d
			keyDown[3] = false;
		}
		
		
		if (keyDown[0] && !keyDown[2]) {
			player1.moveUp();
		}
		if (keyDown[2] && !keyDown[0]) {
			player1.moveDown();
		}
		if (keyDown[1] && !keyDown[3]) {
			player1.moveLeft();
		}
		if (keyDown[3] && !keyDown[1]) {
			player1.moveRight();
		}
		
		if (!keyDown[0] && !keyDown[2]) {
			player1.stopMoveUp();
		}
		if (!keyDown[1] && !keyDown[3]) {
			player1.stopMoveLeft();
		}
		
		if (currentFrame == 1) {
			currentFrame = 0;
		} else if(currentFrame == 11) {
			currentFrame = 10;
		} else if (currentFrame == 4 || currentFrame == 5) {
			currentFrame = 12;//change to standing down pic later
		} else if (currentFrame == 7 || currentFrame == 8) {
			currentFrame = 6;
		}
	}
	
	/**
	 * generates the maze in a handy function
	 */
	public void drawMaze() {
		int y = 5;
		int x = 20;
		for(int i=0; i<874 && i<maze.length(); i++) {
			x=20;
			y+=36;
			while(!maze.substring(i, i+1).equals("\n")) {
				if(!maze.substring(i, i+1).equals(" ")) {
					if(maze.substring(i, i+1).equals("-")) {
						if(i>1 && maze.substring(i-1, i).equals(" ")) {
							this.image(wall, x, y, width/72, height/144);
						}
						else if(i>1 && maze.substring(i+1, i+2).equals(" ") && maze.substring(i+2, i+3).equals("|")) {
							this.image(wall, x, y, width/72, height/144);
						}
//						else if(i>1 && maze.substring(i+1, i+1).equals(" ")) {
//							this.image(wall, x, y, width/72, height/144);
//						}
						else {
							this.image(wall, x, y, width/18, height/36);
						}
					}
					else {
						if(i>1 && maze.substring(i-1, i).equals("-")) {
							this.image(wall, x, y, width/36, height/36);
						}
						else if(i>1 && maze.substring(i-1, i).equals(" ") /*&& !maze.substring(i+1, i+2).equals("\n")*/ && maze.substring(i+1, i+2).equals(" ")) {
							this.image(wall, x, y, width/72, height/40);
						}
						else if(i>1 && maze.substring(i-1, i).equals(" ") && !maze.substring(i+1, i+2).equals("\n") && !maze.substring(i+1, i+2).equals(" ")) {
							this.image(wall, x, y, width/36, height/36);
						}
						else {
							this.image(wall, x, y, width/36, height/18);
						}
						
					}
				}
				i++;
				x+=18;
			}
		}
	}
	

}
